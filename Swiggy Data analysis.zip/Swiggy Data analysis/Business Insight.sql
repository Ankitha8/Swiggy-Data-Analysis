-- Restaurants with Most Variety of Dishes
SELECT TOP 10 [Restaurant_Name],
COUNT(DISTINCT [Dish_Name]) AS total_dishes
FROM dbo.Swiggy_Data
GROUP BY [Restaurant_Name]
ORDER BY total_dishes DESC;

-- Most Reviewed Restaurants
SELECT TOP 10 [Restaurant_Name],
SUM([Rating_Count]) AS total_reviews
FROM dbo.Swiggy_Data
GROUP BY [Restaurant_Name]
ORDER BY total_reviews DESC;
