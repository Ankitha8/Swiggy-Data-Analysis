CREATE VIEW Top_Dishes AS
SELECT [Dish_Name], AVG([Rating]) AS avg_rating
FROM dbo.Swiggy_Data
GROUP BY [Dish_Name];