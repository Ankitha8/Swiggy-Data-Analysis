CREATE VIEW City_Order_Summary AS
SELECT [City], COUNT(*) AS total_orders
FROM dbo.Swiggy_Data
GROUP BY [City];


