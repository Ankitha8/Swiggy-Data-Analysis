-- Total Orders
SELECT COUNT(*) AS total_orders
FROM dbo.Swiggy_Data;

-- Total Cities
SELECT COUNT(DISTINCT [City]) AS total_cities
FROM dbo.Swiggy_Data;

-- Total Restaurants
SELECT COUNT(DISTINCT [Restaurant_Name]) AS total_restaurants
FROM dbo.Swiggy_Data;

-- Total Records
SELECT COUNT(*) AS total_rows
FROM dbo.Swiggy_Data;

-- Total States
SELECT COUNT(DISTINCT [State]) AS total_states
FROM dbo.Swiggy_Data;

-- Total Locations
SELECT COUNT(DISTINCT [Location]) AS total_locations
FROM dbo.Swiggy_Data;

-- Unique Dishes
SELECT COUNT(DISTINCT [Dish_Name]) AS total_dishes
FROM dbo.Swiggy_Data;
