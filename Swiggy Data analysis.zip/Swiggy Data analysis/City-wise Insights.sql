-- Cities with Highest Orders
SELECT TOP 10 [City], COUNT(*) AS total_orders
FROM dbo.Swiggy_Data
GROUP BY [City]
ORDER BY total_orders DESC;

-- Cities with Highest Average Rating
SELECT TOP 10 [City], AVG([Rating]) AS avg_rating
FROM dbo.Swiggy_Data
GROUP BY [City]
ORDER BY avg_rating DESC;

-- Cities with Expensive Food
SELECT TOP 10 [City], AVG([Price_INR]) AS avg_price
FROM dbo.Swiggy_Data
GROUP BY [City]
ORDER BY avg_price DESC;
