-- Average Rating Overall
SELECT AVG([Rating]) AS avg_rating
FROM dbo.Swiggy_Data;

-- Most Popular Dishes (High Rating + High Rating Count)
SELECT TOP 10 [Dish_Name], AVG([Rating]) AS avg_rating,
SUM([Rating_Count]) AS total_reviews
FROM dbo.Swiggy_Data
GROUP BY [Dish_Name]
ORDER BY total_reviews DESC;
