-- Price Range
SELECT 
MIN([Price_INR]) AS min_price,
MAX([Price_INR]) AS max_price,
AVG([Price_INR]) AS avg_price
FROM dbo.Swiggy_Data;

-- Dishes Above Average Price
SELECT *
FROM dbo.Swiggy_Data
WHERE [Price_INR] >
(
SELECT AVG([Price_INR]) FROM dbo.Swiggy_Data
);
