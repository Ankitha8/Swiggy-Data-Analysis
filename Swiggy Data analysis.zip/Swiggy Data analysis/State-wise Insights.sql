-- Orders per State
SELECT [State], COUNT(*) AS total_orders
FROM dbo.Swiggy_Data
GROUP BY [State]
ORDER BY total_orders DESC;

-- Best Rated State
SELECT TOP 1 [State], AVG([Rating]) AS avg_rating
FROM dbo.Swiggy_Data
GROUP BY [State]
ORDER BY avg_rating DESC;
